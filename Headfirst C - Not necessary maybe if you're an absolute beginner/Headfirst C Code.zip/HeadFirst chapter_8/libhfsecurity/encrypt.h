void encrypt(char *message);
