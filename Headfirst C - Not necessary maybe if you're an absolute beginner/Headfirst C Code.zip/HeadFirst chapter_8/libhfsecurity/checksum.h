int checksum(char *message);
