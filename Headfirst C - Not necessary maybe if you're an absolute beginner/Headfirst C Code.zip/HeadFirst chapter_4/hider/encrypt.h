void encrypt (char *message);
